#ifndef HAVE_PTR_RR_H
#define HAVE_PTR_RR_H

#include "adns_rr.h"

namespace ADNS
{
	public ref class PTR_RR : ResourceRecord {
	private: 

		DOMAIN_NAME^ Ptrdname;
		Void UpdateRdata();

	public:
		PTR_RR();
		DOMAIN_NAME^ GetPtrdname();
		Void SetPtrdname(DOMAIN_NAME^ dn);
		String^ Print();
		Void ToCanonical();
		PTR_RR^ Clone();
		static ResourceRecord^ ParseResourceRecord(array<Byte>^ domainname, UInt16 rr_type, UInt16 rr_class, UInt32 ttl, UInt16 rdata_len, array<Byte>^ packet, int rdata_start);
		static String^ PrintRR(ResourceRecord^ rec);
		static ResourceRecord^ CloneRR(ResourceRecord^ rec);

	};


}

#endif