#ifndef HAVE_HINFO_RR_H
#define HAVE_HINFO_RR_H

#include "adns_rr.h"

namespace ADNS 
{
	public ref class HINFO_RR : ResourceRecord {
	private: 
		DNS_CHARSTRING^ cpu;
		DNS_CHARSTRING^ os;
		Void UpdateRdata();

	public:
		HINFO_RR();
		DNS_CHARSTRING^ GetCpu();
		Void SetCpu(array<Byte>^ c);
		Void SetCpu(String^ c);
		DNS_CHARSTRING^ GetOS();
		Void SetOS(array<Byte>^ c);
		Void SetOS(String^ c);
		String^ Print();
		Void ToCanonical();
		HINFO_RR^ Clone();
		static ResourceRecord^ ParseResourceRecord(array<Byte>^ domainname, UInt16 rr_type, UInt16 rr_class, UInt32 ttl, UInt16 rdata_len, array<Byte>^ packet, int rdata_start);		
		static String^ PrintRR(ResourceRecord^ rec);
		static ResourceRecord^ CloneRR(ResourceRecord^ rec);
	};


}

#endif