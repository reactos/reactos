#ifndef HAVE_NS_RR_H
#define HAVE_NS_RR_H

#include "adns_rr.h"

namespace ADNS 
{
	public ref class NS_RR : ResourceRecord {
	private: 

		DOMAIN_NAME^ Nsdname;
		Void UpdateRdata();

	public:
		NS_RR();
		DOMAIN_NAME^ GetNsdname();
		Void SetNsdname(DOMAIN_NAME^ dn);
		String^ Print();
		Void ToCanonical();
		NS_RR^ Clone();
		static ResourceRecord^ ParseResourceRecord(array<Byte>^ domainname, UInt16 rr_type, UInt16 rr_class, UInt32 ttl, UInt16 rdata_len, array<Byte>^ packet, int rdata_start);
		static String^ PrintRR(ResourceRecord^ rec);
		static ResourceRecord^ CloneRR(ResourceRecord^ rec);

	};


}

#endif