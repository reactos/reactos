#ifndef HAVE_ADNS_TXT_RR_H
#define HAVE_ADNS_TXT_RR_H

#include "adns_rr.h"

namespace ADNS {

	public ref class TXT_RR : ResourceRecord
	{
	public:
		TXT_RR();
		Void PushCharString(DNS_CHARSTRING^ cs);
		DNS_CHARSTRING^ PopCharString();
		bool SetCharString(DNS_CHARSTRING^ cs, int pos);
		DNS_CHARSTRING^ GetCharString(int pos);
		String^ Print();
		TXT_RR^ Clone();
		static ResourceRecord^ ParseResourceRecord(array<Byte>^ domainname, UInt16 rr_type, UInt16 rr_class, UInt32 ttl, UInt16 rdata_len, array<Byte>^ packet, int rdata_start);
		static String^ PrintRR(ResourceRecord^ rec);
		static ResourceRecord^ CloneRR(ResourceRecord^ rec);

	private:
		List<DNS_CHARSTRING^>^ strings;
		Void UpdateRdata();
	};

}

#endif
