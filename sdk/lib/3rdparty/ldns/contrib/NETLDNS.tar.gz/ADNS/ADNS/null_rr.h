#ifndef HAVE_NULL_RR_H
#define HAVE_NULL_RR_H

#include "adns_rr.h"

namespace ADNS 
{
	public ref class NULL_RR : ResourceRecord {
	private: 

		array<Byte>^ Data;
		Void UpdateRdata();

	public:
		NULL_RR();
		array<Byte>^ GetData();
		Void SetData(array<Byte>^ dn);
		String^ Print();
		NULL_RR^ Clone();
		static ResourceRecord^ ParseResourceRecord(array<Byte>^ domainname, UInt16 rr_type, UInt16 rr_class, UInt32 ttl, UInt16 rdata_len, array<Byte>^ packet, int rdata_start);
		static String^ PrintRR(ResourceRecord^ rec);
		static ResourceRecord^ CloneRR(ResourceRecord^ rec);
		
	};


}

#endif