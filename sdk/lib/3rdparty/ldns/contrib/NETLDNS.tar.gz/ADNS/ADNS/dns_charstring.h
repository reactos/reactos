#ifndef HAVE_ADNS_DNS_CHARSTRING_H
#define HAVE_ADNS_DNS_CHARSTRING_H

using namespace System;

namespace ADNS 
{

	public ref class DNS_CHARSTRING {
	private:
		array<Byte>^ charstr;
	public:
		DNS_CHARSTRING();
		DNS_CHARSTRING(String^ s);
		array<Byte>^ GetCharacterString();
		Void SetCharacterString(array<Byte>^ cs);
		Void SetCharacterString(String^ s);
		String^ Print();
		DNS_CHARSTRING^ Clone();
		UInt32 Size();
	};

}

#endif
