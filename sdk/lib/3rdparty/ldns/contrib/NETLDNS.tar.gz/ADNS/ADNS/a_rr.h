#ifndef HAVE_ADNS_A_RR_H
#define HAVE_ADNS_A_RR_H

#include "adns_rr.h"

namespace ADNS 
{
	public ref class A_RR : ResourceRecord {
	private: 
		IPAddress^ addr;
		Void UpdateRdata();

	public:
		A_RR();
		A_RR(UInt32 ip);
		A_RR::A_RR(array<Byte>^ ip);
		UInt32 GetAddressAsUInt32();
		IPAddress^ GetAddress();
		Void SetAddress(IPAddress^ ip);
		Void SetAddress(UInt32 ip);
		String^ Print();
		A_RR^ Clone();

		static ResourceRecord^ ParseResourceRecord(array<Byte>^ domainname, UInt16 rr_type, UInt16 rr_class, UInt32 ttl, UInt16 rdata_len, array<Byte>^ packet, int rdata_start);
		static String^ PrintRR(ResourceRecord^ rec);
		static ResourceRecord^ CloneRR(ResourceRecord^ rec);
	};


}

#endif