#ifndef ADNS_HAVE_RRSET_H
#define ADNS_HAVE_RRSET_H

#include "all_rr.h"

using namespace System;

namespace ADNS {

	public ref class RRSet {
	
	public:
		array<ResourceRecord^>^ set;

	public:
		RRSet();
		Void Add(ResourceRecord^ rr);
		RRSet^ GetAllOfType(RR_TYPE type);
		int Length();
		Void ToCanonical();
		Void SortCanonical();
		array<Byte>^ RRSet::GetCanonicalByteArray();
		array<Byte>^ RRSet::GetByteArray();

	
	};

}

#endif
