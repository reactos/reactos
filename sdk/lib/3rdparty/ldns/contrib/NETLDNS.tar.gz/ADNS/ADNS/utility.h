#ifndef HAVE_ADNS_UTILITY_H
#define HAVE_ADNS_UTILITY_H

using namespace System;

namespace ADNS {

	UInt32 DateTimeToTimeStamp(DateTime^ dt);
	DateTime^ TimeStampToDateTime(UInt32 ts);
	Void SetBit(array<Byte>^ bm, unsigned int bit, bool val);
	Byte find_last_non_zero_byte(array<Byte>^ bitmap, int startpos, int checklength);
	int find_length_of_domain_label(array<Byte>^ pkt, int startpos);
	array<Byte>^ ReadDomainFromPacket(array<Byte>^ packet, int startpos, int &reallen);
	String^ ArrayToHexString(array<Byte>^ a);
	array<Byte>^ Base32Encode(array<Byte>^ src);
	array<Byte>^ Base32Decode(array<Byte>^ src);

}

#endif