#ifndef HAVE_ADNS_QUESTION_HEADER_H
#define HAVE_ADNS_QUESTION_HEADER_H

#include "adns_rr.h"

namespace ADNS {

	public ref class QuestionHeader 
	{
	private:
		DOMAIN_NAME^ qname;
		RR_TYPE qtype;
		RR_CLASS qclass;

	public:
		QuestionHeader();
		DOMAIN_NAME^ GetQuestionName();
		Void SetQuestionName(DOMAIN_NAME^ qn);
		RR_TYPE GetQuestionType();
		Void SetQuestionType(RR_TYPE t);
		RR_CLASS GetQuestionClass();
		Void SetQuestionClass(RR_CLASS c);
		array<Byte>^ ToWire();
		String^ Print();
	};

}
#endif
