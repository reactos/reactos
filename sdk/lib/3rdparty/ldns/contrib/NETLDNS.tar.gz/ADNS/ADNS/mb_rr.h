#ifndef HAVE_MB_RR_H
#define HAVE_MB_RR_H

#include "adns_rr.h"

namespace ADNS 
{
	public ref class MB_RR : ResourceRecord {
	private: 

		DOMAIN_NAME^ madname;
		Void UpdateRdata();

	public:
		MB_RR();
		DOMAIN_NAME^ GetMadname();
		Void SetMadname(DOMAIN_NAME^ newname);
		String^ Print();
		Void ToCanonical();
		MB_RR^ Clone();
		static ResourceRecord^ ParseResourceRecord(array<Byte>^ domainname, UInt16 rr_type, UInt16 rr_class, UInt32 ttl, UInt16 rdata_len, array<Byte>^ packet, int rdata_start);
		static String^ PrintRR(ResourceRecord^ rec);
		static ResourceRecord^ CloneRR(ResourceRecord^ rec);
	};


}

#endif