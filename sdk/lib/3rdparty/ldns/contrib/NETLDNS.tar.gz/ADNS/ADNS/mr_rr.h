#ifndef HAVE_MR_RR_H
#define HAVE_MR_RR_H

#include "adns_rr.h"

namespace ADNS 
{
	public ref class MR_RR : ResourceRecord {
	private: 

		DOMAIN_NAME^ newname;
		Void UpdateRdata();

	public:
		MR_RR();
		DOMAIN_NAME^ GetNewname();
		Void SetNewname(DOMAIN_NAME^ dn);
		String^ Print();
		Void ToCanonical();
		MR_RR^ Clone();
		static ResourceRecord^ ParseResourceRecord(array<Byte>^ domainname, UInt16 rr_type, UInt16 rr_class, UInt32 ttl, UInt16 rdata_len, array<Byte>^ packet, int rdata_start);
		static String^ PrintRR(ResourceRecord^ rec);
		static ResourceRecord^ CloneRR(ResourceRecord^ rec);
		
	};


}

#endif