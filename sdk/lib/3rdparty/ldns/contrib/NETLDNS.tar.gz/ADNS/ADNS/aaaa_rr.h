#ifndef HAVE_ADNS_AAAA_RR_H
#define HAVE_ADNS_AAAA_RR_H

#include "adns_rr.h"

namespace ADNS 
{
	public ref class AAAA_RR : ResourceRecord {
	private: 
		IPAddress^ addr;
		Void UpdateRdata();

	public:
		AAAA_RR();
		AAAA_RR(array<Byte>^ ip);
		IPAddress^ GetAddress();
		Void SetAddress(IPAddress^ ip);
		Void SetAddress(array<Byte>^ ip);
		String^ Print();
		AAAA_RR^ Clone();
		static ResourceRecord^ ParseResourceRecord(array<Byte>^ domainname, UInt16 rr_type, UInt16 rr_class, UInt32 ttl, UInt16 rdata_len, array<Byte>^ packet, int rdata_start);
		static String^ PrintRR(ResourceRecord^ rec);
		static ResourceRecord^ CloneRR(ResourceRecord^ rec);
		
	};


}

#endif