#ifndef HAVE_ALL_RR_H
#define HAVE_ALL_RR_H

#include "adns_rr.h"
#include "a_rr.h"
#include "aaaa_rr.h"
#include "cname_rr.h"
#include "dnskey_rr.h"
#include "ds_rr.h"
#include "hinfo_rr.h"
#include "mb_rr.h"
#include "mf_rr.h"
#include "mg_rr.h"
#include "minfo_rr.h"
#include "mr_rr.h"
#include "mx_rr.h"
#include "ns_rr.h"
#include "nsec_rr.h"
#include "nsec3_rr.h"
#include "null_rr.h"
#include "opt_rr.h"
#include "ptr_rr.h"
#include "rrsig_rr.h"
#include "soa_rr.h"
#include "txt_rr.h"


#endif
