#ifndef HAVE_MINFO_RR_H
#define HAVE_MINFO_RR_H

#include "adns_rr.h"

namespace ADNS 
{
	public ref class MINFO_RR : ResourceRecord {
	private: 

		DOMAIN_NAME^ Rmailbx;
		DOMAIN_NAME^ Emailbx;
		Void UpdateRdata();

	public:
		MINFO_RR();
		DOMAIN_NAME^ GetRmailbx();
		DOMAIN_NAME^ GetEmailbx();
		Void SetRmailbx(DOMAIN_NAME^ newname);
		Void SetEmailbx(DOMAIN_NAME^ newname);
		String^ Print();
		Void ToCanonical();
		MINFO_RR^ Clone();
		static ResourceRecord^ ParseResourceRecord(array<Byte>^ domainname, UInt16 rr_type, UInt16 rr_class, UInt32 ttl, UInt16 rdata_len, array<Byte>^ packet, int rdata_start);		
		static String^ PrintRR(ResourceRecord^ rec);
		static ResourceRecord^ CloneRR(ResourceRecord^ rec);
	};


}

#endif