#ifndef HAVE_MF_RR_H
#define HAVE_MF_RR_H

#include "adns_rr.h"

namespace ADNS 
{
	public ref class MF_RR : ResourceRecord {
	private: 

		DOMAIN_NAME^ madname;
		Void UpdateRdata();

	public:
		MF_RR();
		DOMAIN_NAME^ GetMadname();
		Void SetMadname(DOMAIN_NAME^ newname);
		String^ Print();
		Void ToCanonical();
		MF_RR^ Clone();
		static ResourceRecord^ ParseResourceRecord(array<Byte>^ domainname, UInt16 rr_type, UInt16 rr_class, UInt32 ttl, UInt16 rdata_len, array<Byte>^ packet, int rdata_start);
		static String^ PrintRR(ResourceRecord^ rec);
		static ResourceRecord^ CloneRR(ResourceRecord^ rec);
	};


}

#endif